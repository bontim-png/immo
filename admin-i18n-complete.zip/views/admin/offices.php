<?php
declare(strict_types=1);

use App\Csrf;
use App\OfficeService;

$auth->requireSuperAdmin();
function vt(string $key, string $fallback): string { return htmlspecialchars((string)__t($key, $fallback), ENT_QUOTES, 'UTF-8'); }

$service = new OfficeService($db);
$offices = $service->all();

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editOffice = $editId ? $service->find($editId) : null;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=vt('offices.title','Offices')?> - Immo</title>
</head>
<body>

<main>

<h1><?=vt('offices.title','Offices')?></h1>

<p>
    <a href="/immobilier/"><?=vt('common.dashboard','Dashboard')?></a>
</p>

<h2><?= $editOffice ? vt('offices.edit','Edit office') : vt('offices.create','Create office') ?></h2>

<form method="post" action="/immobilier/admin/offices">

    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token(), ENT_QUOTES, 'UTF-8') ?>">
    <input type="hidden" name="action" value="<?= $editOffice ? 'update' : 'create' ?>">

    <?php if ($editOffice): ?>
        <input type="hidden" name="id" value="<?= (int)$editOffice['id'] ?>">
    <?php endif; ?>

    <p>
        <label>
            Name<br>
            <input name="name" required value="<?= htmlspecialchars((string)($editOffice['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Legal name<br>
            <input name="legal_name" value="<?= htmlspecialchars((string)($editOffice['legal_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Email<br>
            <input type="email" name="email" value="<?= htmlspecialchars((string)($editOffice['email'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Phone<br>
            <input name="phone" value="<?= htmlspecialchars((string)($editOffice['phone'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Website<br>
            <input name="website" value="<?= htmlspecialchars((string)($editOffice['website'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Address<br>
            <input name="address_line_1" value="<?= htmlspecialchars((string)($editOffice['address_line_1'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Postcode<br>
            <input name="postcode" value="<?= htmlspecialchars((string)($editOffice['postcode'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            City<br>
            <input name="city" value="<?= htmlspecialchars((string)($editOffice['city'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Country code<br>
            <input name="country_code" maxlength="2" value="<?= htmlspecialchars((string)($editOffice['country_code'] ?? 'FR'), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Language<br>
            <select name="default_language">
                <?php foreach (['fr'=>'Français','en'=>'English','nl'=>'Nederlands'] as $code => $name): ?>
                    <option
                        value="<?= $code ?>"
                        <?= (($editOffice['default_language_id'] ?? '') !== '' && false) ? 'selected' : '' ?>
                    >
                        <?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
    </p>

    <p>
        <label>
            Timezone<br>
            <input name="timezone" value="<?= htmlspecialchars((string)($editOffice['timezone'] ?? 'Europe/Paris'), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <p>
        <label>
            Currency<br>
            <input name="currency_code" maxlength="3" value="<?= htmlspecialchars((string)($editOffice['currency_code'] ?? 'EUR'), ENT_QUOTES, 'UTF-8') ?>">
        </label>
    </p>

    <button type="submit">
        <?= $editOffice ? 'Save office' : 'Create office' ?>
    </button>

    <?php if ($editOffice): ?>
        <a href="/immobilier/admin/offices"><?=vt("common.cancel","Cancel")?></a>
    <?php endif; ?>

</form>

<hr>

<h2><?=vt('offices.directory','Existing offices')?></h2>

<table border="1" cellpadding="8">
<thead>
<tr>
    <th>Name</th>
    <th>City</th>
    <th>Status</th>
    <th>Users</th>
    <th>Agents</th>
    <th>Properties</th>
    <th>Actions</th>
</tr>
</thead>

<tbody>

<?php foreach ($offices as $office): ?>

<tr>

<td>
    <?= htmlspecialchars($office['name'], ENT_QUOTES, 'UTF-8') ?>
</td>

<td>
    <?= htmlspecialchars((string)$office['city'], ENT_QUOTES, 'UTF-8') ?>
</td>

<td>
    <?= (int)$office['is_active'] === 1 ? 'Active' : 'Inactive' ?>
</td>

<td><?= (int)$office['user_count'] ?></td>
<td><?= (int)$office['agent_count'] ?></td>
<td><?= (int)$office['property_count'] ?></td>

<td>

<a href="/immobilier/admin/offices?edit=<?= (int)$office['id'] ?>">
    Edit
</a>

<form method="post" action="/immobilier/admin/offices" style="display:inline">

    <input type="hidden" name="_csrf" value="<?= htmlspecialchars(Csrf::token(), ENT_QUOTES, 'UTF-8') ?>">
    <input type="hidden" name="action" value="toggle">
    <input type="hidden" name="id" value="<?= (int)$office['id'] ?>">
    <input type="hidden" name="active" value="<?= (int)$office['is_active'] === 1 ? 0 : 1 ?>">

    <button type="submit">
        <?= (int)$office['is_active'] === 1 ? 'Deactivate' : 'Activate' ?>
    </button>

</form>

</td>

</tr>

<?php endforeach; ?>

</tbody>
</table>

</main>

</body>
</html>
